#!/bin/bash

# Cloudflare Worker Test Script
# This bypasses browser extensions and tests the worker directly

WORKER_URL="https://flixmax.mohammedamehryunity.workers.dev/"
STREAM_URL="https://one.pacific-base.workers.dev/rainflare53.pro/file2/Qw~ZVG7hN+AE4ZpU9Ih24tZ32+Lona6PbOwrcQ+13VqN~uitjfkSq4SgwElVARbfrCeHzHaVwCvZR1iHQY0VRPzaLds4w+qSJUcmicA+VI06XMZREk0yZ2cKqmYUpQG5f8iT8SU~hQf1vBftPVLtgE0nBZwnE9WBQ4zQo3~Vwg4=/MTA4MA==/aW5kZXgubTN1OA==.m3u8?ti=7f4b2d91"
REFERER="https://api.videasy.net/"
ORIGIN="https://api.videasy.net"

echo "================================"
echo "Cloudflare Worker Test"
echo "================================"
echo ""

# Colors
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

# Test 1: Check if worker is accessible
echo -e "${YELLOW}Test 1: Worker Accessibility${NC}"
echo "Testing: $WORKER_URL"
echo ""

RESPONSE=$(curl -s -o /dev/null -w "%{http_code}" "$WORKER_URL")
if [ "$RESPONSE" -eq 200 ] || [ "$RESPONSE" -eq 400 ]; then
    echo -e "${GREEN}✓ Worker is accessible (HTTP $RESPONSE)${NC}"
else
    echo -e "${RED}✗ Worker not accessible (HTTP $RESPONSE)${NC}"
    echo "  Make sure worker is deployed in Cloudflare Dashboard"
    exit 1
fi
echo ""

# Test 2: CORS Preflight
echo -e "${YELLOW}Test 2: CORS Preflight${NC}"
echo ""

CORS_HEADERS=$(curl -s -X OPTIONS "$WORKER_URL" -i | grep -i "access-control")
if [ -n "$CORS_HEADERS" ]; then
    echo -e "${GREEN}✓ CORS headers present:${NC}"
    echo "$CORS_HEADERS"
else
    echo -e "${RED}✗ CORS headers missing${NC}"
fi
echo ""

# Test 3: Proxy Mode
echo -e "${YELLOW}Test 3: Proxy Mode (M3U8 Fetch)${NC}"
echo ""

# URL encode the parameters properly
ENCODED_DEST=$(python3 -c "import urllib.parse; print(urllib.parse.quote('''$STREAM_URL''', safe=''))")
ENCODED_REF=$(python3 -c "import urllib.parse; print(urllib.parse.quote('''$REFERER''', safe=''))")
ENCODED_ORIG=$(python3 -c "import urllib.parse; print(urllib.parse.quote('''$ORIGIN''', safe=''))")

PROXY_URL="${WORKER_URL}?destination=${ENCODED_DEST}&referer=${ENCODED_REF}&origin=${ENCODED_ORIG}"

echo "Proxy URL (truncated): ${PROXY_URL:0:100}..."
echo "Full URL length: ${#PROXY_URL} characters"
echo ""

# Fetch with verbose output
echo "Fetching manifest..."
RESPONSE=$(curl -s -w "\n---\nHTTP: %{http_code}\nContent-Type: %{content_type}\nTime: %{time_total}s\n" "$PROXY_URL")

HTTP_CODE=$(echo "$RESPONSE" | grep "HTTP:" | cut -d' ' -f2)
CONTENT_TYPE=$(echo "$RESPONSE" | grep "Content-Type:" | cut -d' ' -f2-)
BODY=$(echo "$RESPONSE" | sed -n '1,/^---$/p' | head -n -1)

echo "HTTP Status: $HTTP_CODE"
echo "Content-Type: $CONTENT_TYPE"
echo ""

if [ "$HTTP_CODE" -eq 200 ]; then
    echo -e "${GREEN}✓ Proxy request successful${NC}"
    echo ""

    # Check if valid M3U8
    if echo "$BODY" | grep -q "#EXTM3U"; then
        echo -e "${GREEN}✓ Valid M3U8 manifest received${NC}"
        echo ""
        echo "First 20 lines:"
        echo "$BODY" | head -20
        echo ""

        # Check if URLs are rewritten
        FIRST_URL=$(echo "$BODY" | grep -v "^#" | grep -v "^$" | head -1)
        if echo "$FIRST_URL" | grep -q "flixmax.mohammedamehryunity.workers.dev"; then
            echo -e "${GREEN}✓ URLs are properly proxied${NC}"
            echo "Sample URL: $FIRST_URL"
        else
            echo -e "${RED}✗ URLs are NOT proxied${NC}"
            echo "Sample URL: $FIRST_URL"
            echo "Segments will fail to load!"
        fi
    else
        echo -e "${RED}✗ Not a valid M3U8 manifest${NC}"
        echo "Received:"
        echo "$BODY" | head -10
    fi
else
    echo -e "${RED}✗ Proxy request failed${NC}"
    echo "Response body:"
    echo "$BODY" | head -20
fi
echo ""

# Test 4: Check debug headers
echo -e "${YELLOW}Test 4: Debug Headers${NC}"
echo ""

HEADERS=$(curl -s -I "$PROXY_URL")
DEBUG_URL=$(echo "$HEADERS" | grep -i "x-debug-final-url" | cut -d' ' -f2- | tr -d '\r')
DEBUG_REWRITTEN=$(echo "$HEADERS" | grep -i "x-debug-rewritten" | cut -d' ' -f2- | tr -d '\r')

if [ -n "$DEBUG_URL" ]; then
    echo "X-Debug-Final-Url: $DEBUG_URL"
fi
if [ -n "$DEBUG_REWRITTEN" ]; then
    echo "X-Debug-Rewritten: $DEBUG_REWRITTEN"
fi

echo ""
echo "================================"
echo "Summary"
echo "================================"
echo ""

if [ "$HTTP_CODE" -eq 200 ] && echo "$BODY" | grep -q "#EXTM3U"; then
    echo -e "${GREEN}✓ Worker is functioning correctly!${NC}"
    echo ""
    echo "Next steps:"
    echo "1. If browser test still fails, disable browser extensions"
    echo "2. Try in Incognito/Private mode"
    echo "3. Your actual app (watch.html) should work fine"
else
    echo -e "${RED}✗ Worker has issues${NC}"
    echo ""
    echo "Troubleshooting:"
    echo "1. Verify worker is deployed at Cloudflare Dashboard"
    echo "2. Check worker URL is correct"
    echo "3. Review cloudflare_worker.js for syntax errors"
fi
