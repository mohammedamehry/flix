// Watch Page Logic - Main
document.addEventListener('DOMContentLoaded', initWatch);


function logToUI(msg, type = 'info') {
    console.log(`[${type.toUpperCase()}] ${msg}`);
    const logContainer = document.getElementById('debug-log');
    if (logContainer) {
        const line = document.createElement('div');
        line.style.color = type === 'error' ? '#ff5555' : type === 'success' ? '#5f5' : '#ccc';
        line.textContent = `> ${msg}`;
        logContainer.appendChild(line);
        logContainer.scrollTop = logContainer.scrollHeight;
    }
}


const urlParams = new URLSearchParams(window.location.search);
const MOVIE_ID = urlParams.get('id');

const video = document.getElementById('main-video');
const overlay = document.getElementById('player-overlay');
const playBtn = document.getElementById('center-play-btn');
const progressBar = document.getElementById('progress-bar');
const progressContainer = document.getElementById('progress-container');
const timeDisplay = document.getElementById('time-display');
const titleDisplay = document.getElementById('video-title');

let hideOverlayTimer;

let hlsInstance = null;
let currentTracks = [];
let currentQualities = [];

// Helper: Load Stream (Centralized Logic)
async function loadStream(url, startTime = 0) {
    if (url.includes('.m3u8')) {
        // DEBUG: Fetch manifest first to inspect content
        try {
            logToUI("Verifying stream manifest...", 'info');
            const checkRes = await fetch(url);
            const contentType = checkRes.headers.get("content-type");
            const debugFinalUrl = checkRes.headers.get("x-debug-final-url");
            const debugRewritten = checkRes.headers.get("x-debug-rewritten");

            logToUI(`Manifest Status: ${checkRes.status} (${contentType})`, checkRes.ok ? 'info' : 'error');
            if (debugFinalUrl) logToUI(`Debug Final URL: ${debugFinalUrl.substring(0, 80)}...`, 'info');
            if (debugRewritten) logToUI(`Debug Rewritten: ${debugRewritten}`, 'info');

            if (!checkRes.ok) {
                const errText = await checkRes.text();
                logToUI(`Manifest Error Body: ${errText.substring(0, 200)}`, 'error');
                return; // Stop here
            }

            // Inspect first few chars to ensure it's #EXTM3U
            const text = await checkRes.text();
            logToUI(`Manifest length: ${text.length} bytes`, 'info');
            logToUI(`First 100 chars: ${text.substring(0, 100).replace(/\n/g, '\\n')}`, 'info');

            if (!text.trim().startsWith('#EXTM3U')) {
                const errorMsg = `Invalid Manifest (Not M3U8):\n${text.substring(0, 300)}`;
                logToUI(errorMsg, 'error');
                // Check if it's a JSON error from our worker
                if (text.trim().startsWith('{')) {
                    try {
                        const jsonErr = JSON.parse(text);
                        if (jsonErr.error) {
                            alert(`Worker Error: ${jsonErr.error}`);
                        } else {
                            alert(errorMsg);
                        }
                    } catch (e) { alert(errorMsg); }
                } else {
                    // Likely HTML (Block page)
                    alert(`Stream Blocked. Provider returned HTML instead of Video.\n${text.substring(0, 100)}`);
                }
                return;
            } else {
                logToUI("Manifest valid (#EXTM3U). Loading HLS...", 'success');
            }
        } catch (e) {
            logToUI(`Manifest Check Failed: ${e.message}`, 'error');
        }

        if (Hls.isSupported()) {
            if (hlsInstance) hlsInstance.destroy();
            hlsInstance = new Hls({
                debug: false,
                enableWorker: true,
                lowLatencyMode: false,
                xhrSetup: function (xhr, url) {
                    // Allow cross-origin with credentials for cookies
                    xhr.withCredentials = false;

                    // Debugging XHR
                    xhr.onerror = function () {
                        logToUI(`XHR Error loading ${url.substring(0, 100)}...`, 'error');
                    };
                }
            });

            // Error Handling
            hlsInstance.on(Hls.Events.ERROR, function (event, data) {
                logToUI(`HLS Error: ${data.type} - ${data.details}`, data.fatal ? 'error' : 'info');

                if (data.response && data.response.text) {
                    logToUI(`Response preview: ${data.response.text.substring(0, 200)}`, 'error');
                }

                if (data.fatal) {
                    switch (data.type) {
                        case Hls.ErrorTypes.NETWORK_ERROR:
                            logToUI(`HLS Network Error (fatal): ${data.details}`, 'error');
                            logToUI('Attempting to recover...', 'info');
                            hlsInstance.startLoad();
                            break;
                        case Hls.ErrorTypes.MEDIA_ERROR:
                            logToUI(`HLS Media Error (fatal): ${data.details}`, 'error');
                            logToUI('Attempting to recover...', 'info');
                            hlsInstance.recoverMediaError();
                            break;
                        default:
                            logToUI(`HLS Fatal Error: ${data.details}`, 'error');
                            logToUI('Destroying HLS instance', 'error');
                            hlsInstance.destroy();
                            break;
                    }
                }
            });

            hlsInstance.loadSource(url);
            hlsInstance.attachMedia(video);

            hlsInstance.on(Hls.Events.MANIFEST_PARSED, () => {
                if (startTime > 0) {
                    video.currentTime = startTime;
                }
                video.play().catch(e => logToUI(`Autoplay prevented: ${e.message}`, 'error'));

                const spinner = document.getElementById('buffer-spinner');
                if (spinner) spinner.classList.add('hidden');
            });
        } else if (video.canPlayType('application/vnd.apple.mpegurl')) {
            video.src = url;
            video.addEventListener('loadedmetadata', () => {
                if (startTime > 0) video.currentTime = startTime;
                video.play();
                const spinner = document.getElementById('buffer-spinner');
                if (spinner) spinner.classList.add('hidden');
            });
        }
    } else {
        video.src = url;
        if (startTime > 0) video.currentTime = startTime;
        video.play();
        const spinner = document.getElementById('buffer-spinner');
        if (spinner) spinner.classList.add('hidden');
    }
}

function changeQuality(qualityObj) {
    logToUI(`Switching to ${qualityObj.quality}p`, 'info');
    const currentTime = video.currentTime;

    // Show spinner
    const spinner = document.getElementById('buffer-spinner');
    if (spinner) spinner.classList.remove('hidden');

    // Use the file property (already proxied)
    const streamUrl = qualityObj.file;

    // Use centralized loader
    loadStream(streamUrl, currentTime);

    const qualityMenu = document.getElementById('quality-menu');
    if (qualityMenu) qualityMenu.style.display = 'none';
}

async function initWatch() {
    if (!MOVIE_ID) {
        alert("No movie selected");
        window.location.href = 'index.html';
        return;
    }

    // Helper: Stream Found Callback
    window.onStreamFound = (streamUrl, headers, tracks, qualities) => {
        logToUI(`Playing: ${streamUrl}`, 'success');

        // Store global state
        currentTracks = tracks || [];
        currentQualities = qualities || [];

        // Clear existing tracks
        const existingTracks = video.querySelectorAll('track');
        existingTracks.forEach(t => t.remove());

        // Subtitles
        if (currentTracks.length > 0) {
            currentTracks.forEach(t => {
                const track = document.createElement('track');
                track.kind = 'subtitles';
                track.label = t.label || 'Unknown';
                track.srclang = (t.label || 'en').substring(0, 2).toLowerCase();
                track.src = t.file;
                video.appendChild(track);
            });
            logToUI(`Added ${currentTracks.length} subtitle tracks.`, 'info');
        }

        loadStream(streamUrl);

        setTimeout(() => { if (typeof debug !== 'undefined' && debug) debug.style.display = 'none'; }, 2000);
    };

    // Fetch Details for Title
    try {
        const details = await getMovieDetails(MOVIE_ID);
        if (details) {
            titleDisplay.innerText = details.title || details.name || "Unknown Title";
            document.title = `Watching: ${details.title || details.name}`;

            // Set Backdrop as Poster
            if (details.backdrop_path) {
                video.poster = `https://image.tmdb.org/t/p/original${details.backdrop_path}`;
            }

            // Show spinner
            const spinner = document.getElementById('buffer-spinner');
            if (spinner) spinner.classList.remove('hidden');

            logToUI("Fetching stream from Cloudflare Worker...", 'info');

            // Prepare params for worker
            const year = (details.release_date || '').split('-')[0];
            const isTv = !!details.name;
            const type = isTv ? 'tv' : 'movie';

            let workerUrl = `https://flixmax.mohammedamehryunity.workers.dev/?tmdbId=${details.id}&imdbId=${details.imdb_id}&title=${encodeURIComponent(details.title || details.name)}&year=${year}&type=${type}`;

            if (isTv) {
                // TV Logic: We need season/episode. 
                // For now, let's assume S1 E1 or read from params if available.
                // The current URL params only have 'id'. 
                // We'll stick to movie-centric or defaults for now.
                const season = 1;
                const episode = 1;
                workerUrl += `&season=${season}&episode=${episode}`;
            }

            try {
                logToUI(`Fetching: ${workerUrl.substring(0, 80)}...`, 'info');
                const res = await fetch(workerUrl);

                if (!res.ok) {
                    const errorText = await res.text();
                    throw new Error(`Worker returned ${res.status}: ${errorText.substring(0, 100)}`);
                }

                const data = await res.json();
                logToUI(`Received streams from: ${data.source || 'Unknown'}`, 'success');

                if (data.error) {
                    throw new Error(data.error);
                }

                if (data.streams && data.streams.length > 0) {
                    // Start by sorting streams by quality descending (Highest first)
                    data.streams.sort((a, b) => (b.quality || 0) - (a.quality || 0));

                    // Helper to construct proxy URL with proper encoding
                    const makeProxyUrl = (targetUrl) => {
                        const workerBase = 'https://flixmax.mohammedamehryunity.workers.dev/';
                        const params = new URLSearchParams({
                            destination: targetUrl,
                            referer: data.headers.referer || data.headers.Referer || 'https://api.videasy.net/',
                            origin: data.headers.origin || data.headers.Origin || 'https://api.videasy.net'
                        });
                        const proxyUrl = workerBase + '?' + params.toString();
                        logToUI(`Proxy URL: ${proxyUrl.substring(0, 100)}...`, 'info');
                        return proxyUrl;
                    };

                    const bestStream = data.streams[0];
                    const proxyStreamUrl = makeProxyUrl(bestStream.file);

                    // Map Qualities to include proxy URL
                    const qualities = data.streams.map(q => ({
                        ...q,
                        file: makeProxyUrl(q.file), // Proxy the file URL
                        originalFile: q.file // Keep original just in case
                    }));

                    window.onStreamFound(proxyStreamUrl, data.headers, data.tracks, qualities);
                } else {
                    throw new Error("No streams returned");
                }

            } catch (e) {
                logToUI(`Worker Error: ${e.message}`, 'error');
            }

            if (spinner) spinner.classList.add('hidden');
        }
    } catch (e) {
        console.error("Error init", e);
    }
    // Remove hardcoded setup if we are fetching real streams, or leave as fallback?
    // We removed the hardcoded demo source logic in favor of this dynamic load.

    setupControls();
    startOverlayTimer();
}

function setupControls() {
    // Play/Pause
    playBtn.addEventListener('click', togglePlay);
    video.addEventListener('click', togglePlay);

    // Back
    document.getElementById('back-btn').addEventListener('click', () => {
        window.history.back();
    });

    // Skip Buttons
    document.getElementById('rewind-btn').addEventListener('click', () => skip(-10));
    document.getElementById('forward-btn').addEventListener('click', () => skip(10));

    // Progress Bar Update
    video.addEventListener('timeupdate', updateProgress);

    // Seek
    progressContainer.addEventListener('click', seek);

    // Fullscreen
    document.getElementById('fullscreen-btn').addEventListener('click', toggleFullscreen);

    // Captions/Settings Button Handler
    const captionsBtn = document.querySelector('.bx-captions').parentElement; // Assuming structure
    if (captionsBtn) {
        captionsBtn.addEventListener('click', toggleSettingsMenu);
    }

    // Mouse Activity for Overlay
    document.addEventListener('mousemove', () => {
        showOverlay();
        startOverlayTimer();
    });

    // Keys
    document.addEventListener('keydown', (e) => {
        if (e.code === 'Space') togglePlay();
        if (e.code === 'ArrowRight') skip(10);
        if (e.code === 'ArrowLeft') skip(-10);
        if (e.code === 'Escape') if (document.fullscreenElement) document.exitFullscreen();
    });

    // Quality Button Handler (Top Right)
    const qualityBtn = document.getElementById('quality-btn');
    if (qualityBtn) {
        qualityBtn.addEventListener('click', toggleQualityMenu);
    }
}

// Quality Menu Logic (Top Right)
function toggleQualityMenu() {
    let menu = document.getElementById('quality-menu');
    if (!menu) {
        menu = document.createElement('div');
        menu.id = 'quality-menu';
        menu.className = 'quality-menu';
        Object.assign(menu.style, {
            position: 'absolute',
            top: '60px',
            right: '20px',
            background: 'rgba(20, 20, 20, 0.95)',
            border: '1px solid #333',
            borderRadius: '8px',
            padding: '15px',
            minWidth: '150px',
            color: '#fff',
            zIndex: '1000'
        });
        document.getElementById('player-overlay').appendChild(menu);
    }

    if (menu.style.display === 'none' || !menu.style.display) {
        // Build Content
        menu.innerHTML = '';
        const header = document.createElement('h4');
        header.textContent = "Quality";
        header.style.marginBottom = '10px';
        header.style.borderBottom = '1px solid #444';
        header.style.textAlign = 'center';
        menu.appendChild(header);

        if (currentQualities && currentQualities.length > 0) {
            currentQualities.forEach((q) => {
                const btn = document.createElement('div');
                btn.textContent = `${q.quality || 'Unknown'}p`;
                btn.style.cursor = 'pointer';
                btn.style.padding = '8px';
                btn.style.textAlign = 'center';
                btn.style.fontSize = '14px';
                btn.style.borderBottom = '1px solid #333';

                // Highlight current? (Optimistic)

                btn.onclick = () => {
                    changeQuality(q);
                    menu.style.display = 'none';
                };

                // Hover effect logic could be added via CSS class, 
                // but simpler to leave raw for now or add style
                btn.onmouseover = () => btn.style.background = '#333';
                btn.onmouseout = () => btn.style.background = 'transparent';

                menu.appendChild(btn);
            });
        } else {
            const msg = document.createElement('div');
            msg.textContent = "Auto";
            msg.style.color = '#888';
            msg.style.fontSize = '12px';
            msg.style.padding = '5px';
            menu.appendChild(msg);
        }

        menu.style.display = 'block';
    } else {
        menu.style.display = 'none';
    }
}

// Settings Menu Logic
function toggleSettingsMenu() {
    let menu = document.getElementById('settings-menu');
    if (!menu) {
        // Create Menu if doesn't exist
        menu = document.createElement('div');
        menu.id = 'settings-menu';
        menu.className = 'settings-menu';
        // Add basic styles inline or assumed in CSS (we should probably add style logic here just in case)
        Object.assign(menu.style, {
            position: 'absolute',
            bottom: '60px',
            right: '20px',
            background: 'rgba(20, 20, 20, 0.95)',
            border: '1px solid #333',
            borderRadius: '8px',
            padding: '15px',
            minWidth: '200px',
            color: '#fff',
            zIndex: '1000'
        });

        document.getElementById('player-overlay').appendChild(menu);
    }

    if (menu.style.display === 'none' || !menu.style.display) {
        buildSettingsContent(menu);
        menu.style.display = 'block';
    } else {
        menu.style.display = 'none';
    }
}

function buildSettingsContent(menu) {
    menu.innerHTML = ''; // Clear

    // 1. Qualities Section
    const qualityHeader = document.createElement('h4');
    qualityHeader.textContent = "Quality";
    qualityHeader.style.marginBottom = '5px';
    qualityHeader.style.borderBottom = '1px solid #444';
    menu.appendChild(qualityHeader);

    if (currentQualities && currentQualities.length > 0) {
        currentQualities.forEach((q, index) => {
            const btn = document.createElement('div');
            btn.textContent = `${q.quality || 'Unknown'}p`;
            btn.style.cursor = 'pointer';
            btn.style.padding = '5px';
            btn.style.fontSize = '14px';
            btn.onclick = () => changeQuality(q);
            menu.appendChild(btn);
        });
    } else {
        const msg = document.createElement('div');
        msg.textContent = "Auto / Default";
        msg.style.color = '#888';
        msg.style.fontSize = '12px';
        menu.appendChild(msg);
    }

    // 2. Subtitles Section
    const subHeader = document.createElement('h4');
    subHeader.textContent = "Subtitles";
    subHeader.style.marginTop = '10px';
    subHeader.style.marginBottom = '5px';
    subHeader.style.borderBottom = '1px solid #444';
    menu.appendChild(subHeader);

    // Off Option
    const offBtn = document.createElement('div');
    offBtn.textContent = "Off";
    offBtn.style.cursor = 'pointer';
    offBtn.style.padding = '5px';
    offBtn.onclick = () => disableSubtitles();
    menu.appendChild(offBtn);

    if (currentTracks && currentTracks.length > 0) {
        currentTracks.forEach((track, index) => {
            const btn = document.createElement('div');
            btn.textContent = track.label;
            btn.style.cursor = 'pointer';
            btn.style.padding = '5px';
            btn.style.fontSize = '14px';
            btn.onclick = () => enableSubtitle(index);
            menu.appendChild(btn);
        });
    }
}

// function changeQuality moved up to utilize common loadStream logic

function disableSubtitles() {
    for (let i = 0; i < video.textTracks.length; i++) {
        video.textTracks[i].mode = 'hidden';
    }
    logToUI("Subtitles Off", 'info');
    document.getElementById('settings-menu').style.display = 'none';
}

function enableSubtitle(index) {
    // Disable all first
    for (let i = 0; i < video.textTracks.length; i++) {
        video.textTracks[i].mode = 'hidden';
    }
    // Enable selected (Index mapping might need check if tracks added dynamically)
    // The visual tracks list corresponds to 'currentTracks'. 
    // The DOM textTracks might include others? Usually 1:1 if we cleared them.
    if (video.textTracks[index]) {
        video.textTracks[index].mode = 'showing';
        logToUI(`Subtitle: ${video.textTracks[index].label}`, 'success');
    }
    document.getElementById('settings-menu').style.display = 'none';
}

function togglePlay() {
    if (video.paused) {
        video.play();
        playBtn.innerHTML = "<i class='bx bx-pause'></i>";
    } else {
        video.pause();
        playBtn.innerHTML = "<i class='bx bx-play'></i>";
    }
}

function skip(seconds) {
    video.currentTime += seconds;
}

function updateProgress() {
    const percent = (video.currentTime / video.duration) * 100;
    progressBar.style.width = `${percent}%`;
    timeDisplay.innerText = `${formatTime(video.currentTime)} / ${formatTime(video.duration)}`;
}

function seek(e) {
    const rect = progressContainer.getBoundingClientRect();
    const pos = (e.clientX - rect.left) / rect.width;
    video.currentTime = pos * video.duration;
}

function formatTime(seconds) {
    if (!seconds) return "0:00";
    const m = Math.floor(seconds / 60);
    const s = Math.floor(seconds % 60);
    return `${m}:${s < 10 ? '0' : ''}${s}`;
}

function toggleFullscreen() {
    if (!document.fullscreenElement) {
        document.documentElement.requestFullscreen();
    } else {
        document.exitFullscreen();
    }
}

function showOverlay() {
    overlay.classList.remove('hidden-ui');
    document.body.style.cursor = 'default';
}

function startOverlayTimer() {
    clearTimeout(hideOverlayTimer);
    hideOverlayTimer = setTimeout(() => {
        if (!video.paused) {
            overlay.classList.add('hidden-ui');
            document.body.style.cursor = 'none';
        }
    }, 3000); // Hide after 3s of inactivity
}
