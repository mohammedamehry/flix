# Troubleshooting Guide - HLS Stream Proxy

## Current Issue: "Failed to fetch" Error

### Problem Identified
Your browser extension (ID: `hoklmmgfnpapgjgcpechhaamimifchmp`) is blocking fetch requests to your Cloudflare Worker.

### Solution Options (Try in Order)

---

## Option 1: Test Without Browser Interference (Recommended)

### A. Using Shell Script (Best - No Browser)
```bash
cd /Users/mac/Desktop/anti_netflix
./test-worker.sh
```

This will:
- ✅ Test worker accessibility
- ✅ Check CORS headers
- ✅ Verify proxy mode works
- ✅ Validate M3U8 manifest
- ✅ Confirm URL rewriting

**Expected Output:**
```
✓ Worker is accessible
✓ CORS headers present
✓ Proxy request successful
✓ Valid M3U8 manifest received
✓ URLs are properly proxied
```

### B. Using curl (Quick Test)
```bash
# Test if worker is deployed
curl -I https://flixmax.mohammedamehryunity.workers.dev/

# Should return HTTP 400 (expected - missing parameters)
# Important: Check for "Access-Control-Allow-Origin: *" header
```

---

## Option 2: Browser Without Extensions

### Method A: Incognito/Private Mode
1. Open Chrome/Edge in Incognito mode (Cmd+Shift+N / Ctrl+Shift+N)
2. Navigate to `file:///Users/mac/Desktop/anti_netflix/test-proxy.html`
3. Click "Test Proxy"

### Method B: Disable Extensions
1. Go to `chrome://extensions` or `edge://extensions`
2. Temporarily disable all extensions
3. Refresh test-proxy.html
4. Click "Test Proxy"

### Method C: New Browser Profile
1. Create a new Chrome profile without extensions
2. Test from clean profile

---

## Option 3: Test in Your Actual App

**Important:** Browser extensions usually don't block video element requests, only JavaScript fetch().

Try playing a video directly:

1. Open: `file:///Users/mac/Desktop/anti_netflix/watch.html?id=MOVIE_ID`
2. Check the debug console (bottom-left)
3. Video might work even if test-proxy.html fails!

**Why?** Your video player uses HLS.js which makes requests through the `<video>` element, not fetch(). Extensions typically don't block these.

---

## Common Issues & Solutions

### Issue: Worker Not Deployed
**Symptoms:**
- HTTP 404 or timeout
- No response at all

**Solution:**
1. Go to [Cloudflare Dashboard](https://dash.cloudflare.com/)
2. Navigate to Workers & Pages
3. Find your worker: `flixmax.mohammedamehryunity`
4. Click "Edit Code"
5. Copy contents from `cloudflare_worker.js`
6. Click "Save and Deploy"
7. Wait 30 seconds for deployment
8. Test again

### Issue: CORS Error
**Symptoms:**
- Console shows: "No 'Access-Control-Allow-Origin' header"
- HTTP code 0

**Solution:**
Already fixed in your updated worker code. Redeploy:
```bash
# Check if corsHeaders is defined at top of worker
grep "corsHeaders" cloudflare_worker.js
```

Should show:
```javascript
const corsHeaders = {
    "Access-Control-Allow-Origin": "*",
    ...
};
```

### Issue: M3U8 Not Valid
**Symptoms:**
- Response doesn't start with `#EXTM3U`
- HTML or JSON error returned

**Solution:**
1. Check X-Debug-Final-Url header to see actual URL fetched
2. Test that URL directly in browser
3. Verify upstream service is working

### Issue: Segments Fail to Load
**Symptoms:**
- Manifest loads but video doesn't play
- Network tab shows failed .ts file requests

**Solution:**
Check if URLs in manifest are rewritten:
```bash
curl "https://flixmax.mohammedamehryunity.workers.dev/?destination=STREAM_URL..." | grep "flixmax"
```

Should show worker domain in URLs. If not, check X-Debug-Rewritten header.

### Issue: Video Won't Seek
**Symptoms:**
- Can't skip forward/backward
- Progress bar doesn't work

**Solution:**
Already fixed with Range header support. Redeploy worker.

---

## Verification Checklist

### Worker Deployment ✓
```bash
curl -I https://flixmax.mohammedamehryunity.workers.dev/
# Should return: HTTP 400 (or 200)
# Must have: Access-Control-Allow-Origin: *
```

### CORS Headers ✓
```bash
curl -X OPTIONS https://flixmax.mohammedamehryunity.workers.dev/ -v 2>&1 | grep -i "access-control"
# Should show multiple Access-Control-* headers
```

### Proxy Mode ✓
```bash
./test-worker.sh
# Run the comprehensive test script
```

### M3U8 Rewriting ✓
```bash
# Check first line is #EXTM3U
curl "YOUR_PROXY_URL" | head -1
# Should output: #EXTM3U

# Check URLs are proxied
curl "YOUR_PROXY_URL" | grep "flixmax"
# Should show multiple matches
```

---

## Debug Information to Collect

If still having issues, collect this info:

### 1. Worker Response Headers
```bash
curl -I "https://flixmax.mohammedamehryunity.workers.dev/?test=1"
```

### 2. Proxy Response Sample
```bash
./test-worker.sh > test-results.txt 2>&1
# Share test-results.txt
```

### 3. Browser Console Errors
1. Open DevTools (F12)
2. Go to Console tab
3. Try test-proxy.html
4. Copy all red errors

### 4. Network Request Details
1. Open DevTools → Network tab
2. Try loading video
3. Find failed request
4. Right-click → Copy → Copy as cURL
5. Share the cURL command

---

## Quick Reference: What Works Where

| Test Method | Works With Extensions | Bypasses Extensions | Tests Real Playback |
|-------------|----------------------|---------------------|-------------------|
| test-proxy.html | ❌ No | ❌ No | ❌ No |
| test-worker.sh | ✅ Yes | ✅ Yes | ⚠️ Partial |
| watch.html | ⚠️ Maybe | ⚠️ Maybe | ✅ Yes |
| curl | ✅ Yes | ✅ Yes | ❌ No |
| Incognito Mode | ✅ Yes | ✅ Yes | ✅ Yes |

**Recommendation:** Use `test-worker.sh` first to verify worker works, then test `watch.html` directly.

---

## Expected Working Flow

### Step 1: Verify Worker (Shell)
```bash
./test-worker.sh
```
**Expected:** All tests pass ✓

### Step 2: Test Real Playback
```
Open: watch.html?id=550  (movie ID for Fight Club)
```
**Expected:**
- Debug console shows stream fetching
- Video loads and plays
- Seeking works
- Quality switching works

### Step 3: Troubleshoot if Needed
- If Step 1 fails → Worker deployment issue
- If Step 1 passes but Step 2 fails → Check browser console errors
- If both pass → Success! 🎉

---

## Contact Points

**Working Correctly:**
- Worker responds with HTTP 200/400
- CORS headers present
- M3U8 manifest valid
- URLs rewritten to include worker domain
- Debug headers present (X-Debug-*)

**Not Working:**
- HTTP 404/500/timeout
- Missing CORS headers
- Invalid manifest (HTML/JSON instead of M3U8)
- URLs not rewritten
- Missing debug headers

---

## Next Steps

1. **Run test-worker.sh** - This is your source of truth
2. **If script passes** - Your worker is fine, it's just browser extensions
3. **If script fails** - Follow the error messages in the script output
4. **Test actual video** - watch.html might work even if test-proxy.html doesn't

The key insight: Browser extensions block `fetch()` API but not `<video>` element requests. Your actual app might work fine!
