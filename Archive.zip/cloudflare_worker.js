
export default {
    async fetch(request, env, ctx) {
        // CORS Headers - Apply to ALL responses
        const corsHeaders = {
            "Access-Control-Allow-Origin": "*",
            "Access-Control-Allow-Methods": "GET, POST, OPTIONS, HEAD",
            "Access-Control-Allow-Headers": "*",
            "Access-Control-Expose-Headers": "*",
            "Access-Control-Max-Age": "86400"
        };

        // Handle CORS Preflight
        if (request.method === "OPTIONS") {
            return new Response(null, { headers: corsHeaders });
        }

        const url = new URL(request.url);
        const params = url.searchParams;

        // --- PROXY MODE ---
        const destination = params.get('destination');
        if (destination) {
            // This acts as a proxy that adds the required Referer
            const customReferer = params.get('referer');
            const customOrigin = params.get('origin');

            const allowedReferer = customReferer || "https://player.videasy.net/";
            const allowedOrigin = customOrigin || new URL(allowedReferer).origin;

            // Headers mimicking a real browser (declare outside try block so accessible later)
            const fetchHeaders = new Headers({
                "Referer": allowedReferer,
                "Origin": allowedOrigin,
                "User-Agent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36",
                "Accept": "*/*",
                "Accept-Language": "en-US,en;q=0.9",
                "Sec-Fetch-Dest": "empty",
                "Sec-Fetch-Mode": "cors",
                "Sec-Fetch-Site": "cross-site",
                "Pragma": "no-cache",
                "Cache-Control": "no-cache"
            });

            // Support range requests for video seeking
            const range = request.headers.get('Range');
            if (range) {
                fetchHeaders.set('Range', range);
            }

            // Handle Redirects Manually to preserve Referer & Cookies
            let currentUrl = destination;
            let response = null;
            let redirectCount = 0;
            let cookies = "";

            while (redirectCount < 10) {
                try {
                    // Attach cookies if accumulated
                    if (cookies) {
                        fetchHeaders.set("Cookie", cookies);
                    }

                    response = await fetch(currentUrl, {
                        headers: fetchHeaders,
                        redirect: 'manual'
                    });

                    // Capture Set-Cookie from response to forward
                    const setCookie = response.headers.get("Set-Cookie");
                    if (setCookie) {
                        // Simple append (naive) - for complex cases might need parsing
                        cookies += (cookies ? "; " : "") + setCookie.split(';')[0];
                    }

                    const status = response.status;

                    if (status >= 300 && status < 400) {
                        const location = response.headers.get('Location');
                        if (location) {
                            currentUrl = new URL(location, currentUrl).toString();
                            redirectCount++;
                            continue;
                        }
                    }

                    break;
                } catch (err) {
                    return new Response(JSON.stringify({ error: `Fetch error at ${currentUrl}: ${err.message}` }), {
                        status: 500,
                        headers: { ...corsHeaders, "Content-Type": "application/json" }
                    });
                }
            }

            // Fallback: If 200 but empty body, or 204?
            // The user saw 204. This might be a specific upstream behavior.
            if (response.status === 204) {
                // Try one last "follow" attempt as hail mary
                response = await fetch(currentUrl, {
                    headers: fetchHeaders,
                    redirect: 'follow'
                });
            }

            if (!response || !response.ok) {
                // Propagate the error status if possible
                const errorBody = response ? await response.text() : "Proxy failed to fetch content";
                return new Response(JSON.stringify({ error: errorBody, url: currentUrl }), {
                    status: response ? response.status : 502,
                    headers: { ...corsHeaders, "Content-Type": "application/json" }
                });
            }

            // CHECK FOR M3U8 to Rewrite
            const contentType = response.headers.get("Content-Type") || "";
            let body = response.body;
            let rewritten = false;

            if (contentType.includes("javascript") || contentType.includes("mpegurl") || currentUrl.includes(".m3u8")) {
                try {
                    const text = await response.text();
                    const workerBase = new URL(request.url).origin + new URL(request.url).pathname;

                    // Rewrite Content
                    const lines = text.split('\n');
                    const rewrittenLines = lines.map(line => {
                        const trimmed = line.trim();
                        if (trimmed && !trimmed.startsWith('#')) {
                            // It's a URL (segment or playlist)
                            // Resolve against the LAST currentUrl (after redirects)
                            try {
                                const absoluteUrl = new URL(trimmed, currentUrl).toString();

                                // Re-encode for proxy params
                                return `${workerBase}?destination=${encodeURIComponent(absoluteUrl)}&referer=${encodeURIComponent(allowedReferer)}&origin=${encodeURIComponent(allowedOrigin)}`;
                            } catch (e) { return line; }
                        }
                        return line;
                    });

                    body = rewrittenLines.join('\n');
                    rewritten = true;
                } catch (e) {
                    // Fallback to original body if text() failed
                    // (But we can't really read body twice unless we cloned, but we awaited text so stream is consumed)
                    // Getting here means text() failed, so body is lost or empty.
                    // We return error.
                    return new Response(JSON.stringify({ error: "Error rewriting M3U8", details: e.message }), {
                        status: 500,
                        headers: { ...corsHeaders, "Content-Type": "application/json" }
                    });
                }
            }

            // Re-create headers with CORS
            const newHeaders = new Headers();

            // Copy safe headers from response
            const safeHeaders = ['content-type', 'content-range', 'accept-ranges', 'etag', 'last-modified'];
            for (const header of safeHeaders) {
                const value = response.headers.get(header);
                if (value) newHeaders.set(header, value);
            }

            // Add CORS headers
            Object.entries(corsHeaders).forEach(([key, value]) => {
                newHeaders.set(key, value);
            });

            // Debug headers
            newHeaders.set("X-Debug-Final-Url", currentUrl);
            newHeaders.set("X-Debug-Rewritten", rewritten.toString());

            // Force 200 if we rewrote content (since our body is valid, even if upstream was 204/Partial)
            const finalStatus = rewritten ? 200 : response.status;
            const finalStatusText = rewritten ? "OK" : response.statusText;

            return new Response(body, {
                status: finalStatus,
                statusText: finalStatusText,
                headers: newHeaders
            });
        }

        // --- API MODE ---
        // Extract parameters
        const tmdbId = params.get('tmdbId');
        const imdbId = params.get('imdbId');
        const type = params.get('type') || 'movie'; // movie or tv
        const year = params.get('year');
        const title = params.get('title');
        const season = params.get('season');
        const episode = params.get('episode');

        if (!tmdbId || !title) {
            return new Response(JSON.stringify({ error: "Missing required parameters (tmdbId, title)" }), {
                status: 400,
                headers: {
                    ...corsHeaders,
                    "Content-Type": "application/json"
                }
            });
        }

        try {
            const sources = await getSources({ tmdbId, imdbId, type, year, title, season, episode });
            return new Response(JSON.stringify(sources), {
                headers: {
                    ...corsHeaders,
                    "Content-Type": "application/json"
                }
            });
        } catch (e) {
            return new Response(JSON.stringify({ error: e.message, stack: e.stack }), {
                status: 500,
                headers: {
                    ...corsHeaders,
                    "Content-Type": "application/json"
                }
            });
        }
    },
};

async function getSources(movieInfo) {
    const PROVIDER = 'AVideasy';
    const DOMAIN = "https://api.videasy.net";
    const headers = {
        'user-agent': "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36",
        'referer': `${DOMAIN}/`,
        "origin": `${DOMAIN}` // Cloudflare Workers can set this safely
    };

    const sources = ["myflixerzupcloud"];

    // Logic adapted from decryptvds.js
    for (const source of sources) {
        try {
            let url = `https://api.videasy.net/myflixerzupcloud/sources-with-title?mediaType=${movieInfo.type}&year=${movieInfo.year}&tmdbId=${movieInfo.tmdbId}&imdbId=${movieInfo.imdbId}&title=${encodeURIComponent(movieInfo.title)}`;

            if (movieInfo.type === "tv") {
                url += `&episodeId=${movieInfo.episode}&seasonId=${movieInfo.season}`;
            }

            const response = await fetch(url, { headers });
            const textDetail = await response.text();

            if (!textDetail) continue;

            // Decrypt Logic
            const urlDecrypt = "https://enc-dec.app/api/dec-videasy";
            const body = {
                text: textDetail,
                id: movieInfo.tmdbId
            };

            const decResponse = await fetch(urlDecrypt, {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify(body)
            });
            const decryptData = await decResponse.json();

            if (!decryptData || !decryptData.result || !decryptData.result.sources) continue;

            // Process Sources
            let directQuality = [];
            const tracks = [];

            if (decryptData.result.sources) {
                for (const item of decryptData.result.sources) {
                    let quality = item.quality;
                    const match = quality && quality.match(/([0-9]+)/i);
                    quality = match ? Number(match[1]) : 1080;

                    directQuality.push({
                        file: item.url,
                        quality: quality,
                        type: 'hls' // Assuming HLS based on context
                    });
                }
            }

            if (decryptData.result.subtitles) {
                for (const sub of decryptData.result.subtitles) {
                    tracks.push({
                        file: sub.url,
                        kind: 'captions',
                        label: sub.language
                    });
                }
            }

            if (directQuality.length === 0) continue;

            // Sort by quality desc
            directQuality.sort((a, b) => b.quality - a.quality);

            return {
                source: PROVIDER,
                streams: directQuality,
                tracks: tracks,
                headers: headers // Return the headers needed for playback
            };

        } catch (e) {
            console.error(`Error processing source ${source}:`, e);
            continue;
        }
    }

    throw new Error("No streams found");
}