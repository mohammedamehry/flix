# Quick Start Guide - Stream Proxy Setup

## What Was Fixed

### Critical Bug Fixed ✅
Your Cloudflare worker was missing a **return statement** at line 164, causing proxy requests to fail silently.

### Improvements Added ✅
1. **CORS Headers** - Now properly set on all responses
2. **Range Request Support** - Enables video seeking
3. **Better Error Handling** - All errors return JSON with CORS headers
4. **URL Encoding Fix** - Using URLSearchParams for proper encoding
5. **Debug Logging** - Visible console for troubleshooting

## How to Deploy

### Step 1: Deploy Cloudflare Worker

**Option A - Cloudflare Dashboard**:
1. Go to Workers & Pages in Cloudflare Dashboard
2. Edit your worker: `flixmax.mohammedamehryunity`
3. Replace code with updated `cloudflare_worker.js`
4. Click "Save and Deploy"

**Option B - Wrangler CLI**:
```bash
cd /Users/mac/Desktop/anti_netflix
wrangler deploy cloudflare_worker.js
```

### Step 2: Test the Proxy

**Option A - Using Test Page**:
```bash
# Open in browser
open test-proxy.html
```
Click "Test Proxy" button - should show:
- ✅ Response: 200 OK
- ✅ Valid M3U8 manifest
- ✅ URLs are proxied

**Option B - Using curl**:
```bash
# Test CORS
curl -X OPTIONS "https://flixmax.mohammedamehryunity.workers.dev/" -v

# Test Proxy (check for Access-Control-Allow-Origin header)
curl "https://flixmax.mohammedamehryunity.workers.dev/?destination=https%3A%2F%2Fexample.com%2Ftest.m3u8&referer=https%3A%2F%2Fapi.videasy.net%2F&origin=https%3A%2F%2Fapi.videasy.net" -v
```

### Step 3: Test Video Playback

1. Open your app: `open watch.html?id=MOVIE_ID`
2. Check bottom-left debug console for:
   - ✅ "Fetching stream from Cloudflare Worker..."
   - ✅ "Received streams from: AVideasy"
   - ✅ "Proxy URL: https://flixmax..."
   - ✅ "Manifest valid (#EXTM3U). Loading HLS..."
   - ✅ Video plays!

## Troubleshooting

### Issue: "HTTP response code: 0"
**Cause**: Worker not deployed or CORS issue
**Fix**:
1. Ensure worker is deployed (check Cloudflare dashboard)
2. Test with test-proxy.html
3. Check browser console for errors

### Issue: "manifestLoadError"
**Cause**: Upstream blocking request
**Fix**:
1. Open browser DevTools Network tab
2. Find failed request
3. Check "X-Debug-Final-Url" response header
4. Test that URL directly in test-proxy.html

### Issue: Video plays but won't seek
**Cause**: Range requests not working
**Fix**: Already fixed - redeploy worker

### Issue: Quality switching fails
**Cause**: Quality URLs not proxied
**Fix**: Already fixed in watch.js - clear cache and reload

## File Changes Summary

### Modified Files:
- ✅ `cloudflare_worker.js` - Added return statement, CORS, Range support
- ✅ `js/watch.js` - Better URL encoding, more logging
- ✅ `watch.html` - Enabled debug console

### New Files:
- ✅ `test-proxy.html` - Testing tool for proxy functionality
- ✅ `PROXY-SOLUTION.md` - Detailed documentation
- ✅ `QUICK-START.md` - This file

## Next Steps

1. **Deploy** the updated worker (see Step 1)
2. **Test** with test-proxy.html
3. **Try** playing a video in watch.html
4. **Monitor** the debug console for any issues

## Need Help?

### Check Debug Console
The debug log (bottom-left of video player) shows:
- API requests to worker
- Proxy URL construction
- Manifest loading status
- HLS.js errors

### Check Network Tab
Browser DevTools → Network:
- Look for worker requests (flixmax.mohammedamehryunity.workers.dev)
- Check response headers (Access-Control-Allow-Origin, X-Debug-*)
- Verify manifest content (should start with #EXTM3U)

### Common Headers to Check:
```
Access-Control-Allow-Origin: *
Access-Control-Allow-Methods: GET, POST, OPTIONS, HEAD
Access-Control-Expose-Headers: *
X-Debug-Final-Url: <actual upstream URL>
X-Debug-Rewritten: true
Content-Type: application/vnd.apple.mpegurl
```

## How It Works (Simple Version)

```
Your App (watch.js)
    ↓
  Calls Worker API
  (gets stream URLs + headers)
    ↓
  Builds Proxy URL:
  worker.dev/?destination=STREAM&referer=REF&origin=ORIGIN
    ↓
  HLS.js loads proxied manifest
    ↓
  Worker fetches with custom headers
  Worker rewrites all URLs to proxy
    ↓
  Returns to browser with CORS
    ↓
  HLS.js loads segments (also proxied)
    ↓
  Video plays! 🎉
```

That's it! Your setup is complete and ready to use.
