# Quick Test - Is Your Worker Working?

## The Problem
A browser extension (ID: `hoklmmgfnpapgjgcpechhaamimifchmp`) is blocking your test page.

**This doesn't mean your worker is broken!** It just means the test page can't reach it through that extension.

---

## Quick Test (Copy & Paste in Terminal)

### Test 1: Is worker deployed?
```bash
curl -i https://flixmax.mohammedamehryunity.workers.dev/ 2>&1 | head -20
```

**What to look for:**
- ✅ `HTTP/2 400` or `HTTP/2 200` = Worker is deployed
- ✅ `access-control-allow-origin: *` = CORS is working
- ❌ `HTTP/2 404` or timeout = Worker not deployed
- ❌ No `access-control` headers = Old worker code

### Test 2: Does proxy mode work?
```bash
curl -s "https://flixmax.mohammedamehryunity.workers.dev/?destination=https%3A%2F%2Fone.pacific-base.workers.dev%2Frainflare53.pro%2Ffile2%2FQw~ZVG7hN%2BAE4ZpU9Ih24tZ32%2BLona6PbOwrcQ%2B13VqN~uitjfkSq4SgwElVARbfrCeHzHaVwCvZR1iHQY0VRPzaLds4w%2BqSJUcmicA%2BVI06XMZREk0yZ2cKqmYUpQG5f8iT8SU~hQf1vBftPVLtgE0nBZwnE9WBQ4zQo3~Vwg4%3D%2FMTA4MA%3D%3D%2FaW5kZXgubTN1OA%3D%3D.m3u8%3Fti%3D7f4b2d91&referer=https%3A%2F%2Fapi.videasy.net%2F&origin=https%3A%2F%2Fapi.videasy.net" | head -3
```

**What to look for:**
- ✅ First line: `#EXTM3U` = Working perfectly!
- ❌ `{"error":...}` = Worker error (check message)
- ❌ `<html>` or blank = Not working

### Test 3: Are URLs being rewritten?
```bash
curl -s "https://flixmax.mohammedamehryunity.workers.dev/?destination=https%3A%2F%2Fone.pacific-base.workers.dev%2Frainflare53.pro%2Ffile2%2FQw~ZVG7hN%2BAE4ZpU9Ih24tZ32%2BLona6PbOwrcQ%2B13VqN~uitjfkSq4SgwElVARbfrCeHzHaVwCvZR1iHQY0VRPzaLds4w%2BqSJUcmicA%2BVI06XMZREk0yZ2cKqmYUpQG5f8iT8SU~hQf1vBftPVLtgE0nBZwnE9WBQ4zQo3~Vwg4%3D%2FMTA4MA%3D%3D%2FaW5kZXgubTN1OA%3D%3D.m3u8%3Fti%3D7f4b2d91&referer=https%3A%2F%2Fapi.videasy.net%2F&origin=https%3A%2F%2Fapi.videasy.net" | grep "flixmax" | head -1
```

**What to look for:**
- ✅ URLs contain `flixmax.mohammedamehryunity.workers.dev` = Perfect!
- ❌ URLs don't contain worker domain = URLs not being proxied

---

## Comprehensive Test (Run Script)

```bash
cd /Users/mac/Desktop/anti_netflix
./test-worker.sh
```

This tests everything and gives you a detailed report.

---

## What Each Result Means

### ✅ All Tests Pass
**Meaning:** Your worker is perfect! The browser extension is just blocking test-proxy.html

**Next Steps:**
1. Try opening watch.html with a real movie ID
2. The actual video player will likely work fine
3. Browser extensions usually don't block `<video>` element requests

**Test actual playback:**
```bash
# Just open this in your browser:
open watch.html?id=550
```

### ❌ Test 1 Fails (Worker not responding)
**Meaning:** Worker isn't deployed or URL is wrong

**Fix:**
1. Go to Cloudflare Dashboard
2. Workers & Pages → flixmax.mohammedamehryunity
3. Make sure it's deployed
4. Check the URL matches exactly

### ❌ Test 2 Fails (No #EXTM3U)
**Meaning:** Proxy mode has an error

**Fix:**
1. Check what error message is returned
2. Verify cloudflare_worker.js has the latest code
3. Redeploy worker

### ❌ Test 3 Fails (URLs not rewritten)
**Meaning:** M3U8 rewriting logic not working

**Fix:**
1. Check X-Debug-Rewritten header: `curl -I "PROXY_URL" | grep -i debug`
2. Should show `X-Debug-Rewritten: true`
3. If false, check worker's URL rewriting code

---

## The Real Test: Does Video Play?

Forget test-proxy.html for now. Try the actual player:

1. **Open in browser:** `watch.html?id=550` (Fight Club)
2. **Look at debug console** (bottom-left, green text)
3. **Watch for:**
   - "Fetching stream from Cloudflare Worker..."
   - "Received streams from: AVideasy"
   - "Playing: https://flixmax..."
   - Video starts playing

**If video plays:** Your worker is working perfectly! The test page issue is just the browser extension.

**If video doesn't play:** Check the debug console errors and browser DevTools console.

---

## TL;DR

1. Run: `./test-worker.sh`
2. If it passes: Try `watch.html?id=550` in your browser
3. If watch.html works: **You're done!** Everything works.
4. If watch.html fails: Check browser console for actual error

**The key point:** test-proxy.html failing doesn't mean your solution is broken. The extension is just blocking the test, not your actual video player.
